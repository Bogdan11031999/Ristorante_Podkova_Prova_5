package com.example.ristorante_podkova_prova_5

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ListView
import android.widget.TextView

class ActivityType : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_type)
        val type =  intent.getStringExtra("type")
        val floor = intent.getIntExtra("floor", 0)
        val table = intent.getIntExtra("table", 0)
        val textView = findViewById<TextView>(R.id.textViewType)
        textView.setText("ЭТАЖ: "+floor+" СТОЛ: "+table+" КАТ: "+type)

        val listView = findViewById<ListView>(R.id.listViewType)

        val dataList = listOf("Подкова", "Селёдка малосольная", "Селёдка под шубой", "Нарезка колбасная", "Сёмга малого посола", "Салат столичный", "Русские разносолы", "Салат из помидор, огурцов, лука и укропа")
        val adapter = CustomListType(this, dataList)
        listView.adapter = adapter
    }
}